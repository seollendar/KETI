package kafkaTutorial.tutorial;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import org.json.JSONObject;

import java.util.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

public class Consumer_v2 {

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

		/*REDIS*/
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		JedisPool pool = new JedisPool(jedisPoolConfig, "127.0.0.1", 6379, 1000);
		Jedis jedis = pool.getResource();

		/*KAFKA*/
		Properties configs = new Properties();
		configs.put("bootstrap.servers", "localhost:9092");     
		configs.put("session.timeout.ms", "10000");             
		configs.put("group.id", "kafka-nodejs-group");          
		configs.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");    
		configs.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
		configs.put("fetch.max.wait.ms", "5000");
		configs.put("fetch.min.bytes", "1");
		configs.put("fetch.max.bytes", "104857600");
		configs.put("enable.auto.commit", "false");
		configs.put("max.poll.records", "50000");
		configs.put("auto.offset.reset", "earliest");

		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(configs);            
		consumer.subscribe(Collections.singletonList("fullNotification"));      // topic 설정 notifi(100000)

		int count = 0, message_count = 0;
		try {
			long start = System.currentTimeMillis();
			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(1000);
				count++;
				for (ConsumerRecord<String, String> record : records) { //String
					//System.out.println("record.value(): " + record.value());
					String recordOfKafka = record.value();

					JSONObject notiObj = new JSONObject(recordOfKafka);
					JSONObject post1Object = notiObj.getJSONObject("m2m:sgn");
					JSONObject post2Object = post1Object.getJSONObject("nev");
					JSONObject post3Object = post2Object.getJSONObject("rep");
					JSONObject post4Object = post3Object.getJSONObject("m2m:cin");
					JSONObject currentConData = post4Object.getJSONObject("con");
					double currentLatitude = currentConData.getDouble("latitude");
					double currentLongitude = currentConData.getDouble("longitude");
					String currentTime = currentConData.getString("time");
					Date currentTimeParse = format.parse(currentTime);
					//System.out.println("currentTimeParse: "+ currentTimeParse);



					//	        	    String getPreviousDataFromRedis = jedis.get("previousData");
					//	        		if(getPreviousDataFromRedis == null) {
					//	        			String setStringDataToRedis = currentConData.toString();
					//		        	    jedis.set("previousData", setStringDataToRedis);	
					//		        	    //System.out.println("redis set");
					//		        	    
					//	        		}else {
					//		        		//System.out.println("redis result :" + getPreviousDataFromRedis);
					//		        		JSONObject PreviousConData = new JSONObject(getPreviousDataFromRedis);
					//		        		double previousLatitude = PreviousConData.getDouble("latitude");
					//		        		double previousLongitude = PreviousConData.getDouble("longitude");
					//		        		String previousTime = PreviousConData.getString("time");
					//		        		Date previousTimeParse = format.parse(previousTime);
					//		        		
					//		        		long Timediff = (currentTimeParse.getTime() - previousTimeParse.getTime())/1000;
					//		        		//System.out.println("\n diff: "+ Timediff);
					//		        		
					//		        		
					//		        		/*set previousData to Redis*/
					//		        		String setStringDataToRedis = currentConData.toString();
					//		        		jedis.set("previousData", setStringDataToRedis);
					//	        		}


					message_count++;
					//System.out.println("message_count: "+ message_count);	            	
				}
				long end = System.currentTimeMillis();


				if(message_count == 100000) { 
					System.out.println( "실행 시간 : " + ( end - start ) + "\ncount: " + count + "\nmessage_count: " + message_count); 
				}

				//System.out.println("count: "+ count);
				//System.out.println("msg_count: "+ message_count+ "\n"); //sysout 'ctrl+space'

			}
		}finally {       	
			consumer.close();
			pool.close();
		}

	}

}