package kafkaTutorial.tutorial;

import org.json.JSONException;
import org.json.JSONObject;


public class JsonParser {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		String JSON_TEST_DATA = "{\"m2m:sgn\":{\"nev\":{\"rep\":{\"m2m:cin\":{\"ty\":4,\"ri\":\"cin00S02f9ecfd6-35ef-451e-8672-09ab3ec09a141603350091457\",\"rn\":\"cin-S02f9ecfd6-35ef-451e-8672-09ab3ec09a141603350091457\",\"pi\":\"cnt00000000000001951\",\"ct\":\"20201022T160131\",\"lt\":\"20201022T160131\",\"et\":\"20201121T160131\",\"st\":903335,\"cr\":\"SS01228427453\",\"cnf\":\"application/json\",\"cs\":155,\"con\":{\"i\":999,\"latitude\":28.5036018,\"longitude\":129.0953344,\"altitude\":12.934,\"velocity\":0,\"direction\":0,\"time\":\"2020-12-01T04:27:47\",\"position_fix\":1,\"satelites\":0,\"state\":\"ON\"}}},\"om\":{\"op\":1,\"org\":\"SS01228427453\"}},\"vrq\":false,\"sud\":false,\"sur\":\"/~/CB00061/smartharbor/dt1/scnt-location/sub-S01228427453_user\",\"cr\":\"SS01228427453\"}}";
//		
//		final JSONObject testObj = new JSONObject(JSON_TEST_DATA);
//		System.out.println("testObj.getString(\"m2m:cin\"): "+testObj.get("m2m:sgn").get()+"\n");
//	    System.out.println("testObj.toString()" + testObj.toString());
//	}
//
//}


	private final static String JSON_TEST_DATA 
	= "{\"m2m:sgn\":{\"nev\":{\"rep\":{\"m2m:cin\":{\"ty\":4,\"ri\":\"cin00S02f9ecfd6-35ef-451e-8672-09ab3ec09a141603350091457\",\"rn\":\"cin-S02f9ecfd6-35ef-451e-8672-09ab3ec09a141603350091457\",\"pi\":\"cnt00000000000001951\",\"ct\":\"20201022T160131\",\"lt\":\"20201022T160131\",\"et\":\"20201121T160131\",\"st\":903335,\"cr\":\"SS01228427453\",\"cnf\":\"application/json\",\"cs\":155,\"con\":{\"i\":992,\"latitude\":28.4966018,\"longitude\":129.0953344,\"altitude\":12.934,\"velocity\":0,\"direction\":0,\"time\":\"2020-12-01T04:42:39\",\"position_fix\":1,\"satelites\":0,\"state\":\"ON\"}}},\"om\":{\"op\":1,\"org\":\"SS01228427453\"}},\"vrq\":false,\"sud\":false,\"sur\":\"/~/CB00061/smartharbor/dt1/scnt-location/sub-S01228427453_user\",\"cr\":\"SS01228427453\"}}";
	

	public static void main (String arg[]) throws JSONException{
	
	    //System.out.println(JSON_TEST_DATA);
	    JSONObject notiObj = new JSONObject(JSON_TEST_DATA);
	    JSONObject post1Object = notiObj.getJSONObject("m2m:sgn");
	    JSONObject post2Object = post1Object.getJSONObject("nev");
	    JSONObject post3Object = post2Object.getJSONObject("rep");
	    JSONObject post4Object = post3Object.getJSONObject("m2m:cin");
	    JSONObject post5Object = post4Object.getJSONObject("con");
	    Object altitude = post5Object.get("altitude"); //Double
	    
	    
	    System.out.println(altitude+"\n"+ altitude.getClass().getName());
	    
	    
	}

}