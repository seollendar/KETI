package kafkaTutorial.tutorial;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import org.json.JSONObject;

import java.util.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

public class Consumer_v4 {

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

		/*REDIS*/
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		JedisPool pool = new JedisPool(jedisPoolConfig, "127.0.0.1", 6379, 1000);
		Jedis jedis = pool.getResource();

		/*KAFKA*/
		Properties configs = new Properties();
		configs.put("bootstrap.servers", "localhost:9092");     
		configs.put("session.timeout.ms", "10000");             
		configs.put("group.id", "kafka-nodejs-group");          
		configs.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");    
		configs.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
		configs.put("fetch.max.wait.ms", "5000");
		configs.put("fetch.min.bytes", "1");
		configs.put("fetch.max.bytes", "104857600");
		configs.put("enable.auto.commit", "false");
		configs.put("max.poll.records", "50000");
		configs.put("auto.offset.reset", "earliest");

		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(configs);            
		consumer.subscribe(Collections.singletonList("fullNotification"));      // topic 설정 notifi(100000)

		int count = 0, message_count = 0;
		try {
			long start = System.currentTimeMillis();
			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(1000);
				count++;
				for (ConsumerRecord<String, String> record : records) { //String
					String recordOfKafka = record.value();

					JSONObject notiObj = new JSONObject(recordOfKafka);
					JSONObject post1Object = notiObj.getJSONObject("m2m:sgn");
					JSONObject post2Object = post1Object.getJSONObject("nev");
					JSONObject post3Object = post2Object.getJSONObject("rep");
					JSONObject post4Object = post3Object.getJSONObject("m2m:cin");
					JSONObject currentConData = post4Object.getJSONObject("con");
					//System.out.println("currenntData: " + currentConData);
					double currentLatitude = currentConData.getDouble("latitude");
					double currentLongitude = currentConData.getDouble("longitude");
					String currentTime = currentConData.getString("time");
					Date currentTimeParse = format.parse(currentTime);


					String getPreviousDataFromRedis = jedis.get("previousData");
					if(getPreviousDataFromRedis == null) {
						String setStringDataToRedis = currentConData.toString();
						jedis.set("previousData", setStringDataToRedis);   
						//System.out.println("redis set");

					}else {
						//System.out.println("previousData :" + getPreviousDataFromRedis);
						JSONObject PreviousConData = new JSONObject(getPreviousDataFromRedis);
						double previousLatitude = PreviousConData.getDouble("latitude");
						double previousLongitude = PreviousConData.getDouble("longitude");
						String previousTime = PreviousConData.getString("time");
						Date previousTimeParse = format.parse(previousTime);			

						double preprocessingSpeed = getSpeed(previousLatitude, previousLongitude, previousTimeParse, currentLatitude, currentLongitude, currentTimeParse);
						double preprocessingDistance = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);
						double preprocessingDirection = getDirection(previousLatitude, previousLongitude, currentLatitude, currentLongitude);
						//					
						//					System.out.println("-Speed "+ preprocessingSpeed + "\n-Distance: "+ preprocessingDistance + "\n-Direction: "+ preprocessingDirection);

						/*set previousData to Redis*/
						String setStringDataToRedis = currentConData.toString();
						jedis.set("previousData", setStringDataToRedis);
					}

					message_count++;       
				}
				long end = System.currentTimeMillis();

				if(message_count == 100000) {
					System.out.println( "실행 시간 : " + ( end - start ) + "\ncount: " + count + "\nmessage_count: " + message_count); 
				}

			}
		}finally {          
			consumer.close();
			pool.close();
		}

	}


	/*Speed*/
	public static double getSpeed(double previousLatitude, double previousLongitude, Date previousTimeParse, double currentLatitude, double currentLongitude, Date currentTimeParse) {
		double distancePerM = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);//이동거리(m)
		long TimeDiff = (currentTimeParse.getTime() - previousTimeParse.getTime())/1000; // 단위:s
		double computevelocity = computespeed(TimeDiff, distancePerM);//이동속도

		return computevelocity;
	}

	/*Distance*/
	public static double getDistance(double previousLatitude, double previousLongitude, double currentLatitude, double currentLongitude) {
		double p = 0.017453292519943295;    // Math.PI / 180
		double a = 0.5 - Math.cos((currentLatitude - previousLatitude) * p)/2 + Math.cos(previousLatitude * p) * Math.cos(currentLatitude * p) * (1 - Math.cos((currentLongitude - previousLongitude) * p))/2;
		return (12742 * Math.asin(Math.sqrt(a))*1000);
	}

	/*bearing*/
	public static double getDirection(double lat1, double lon1, double lat2, double lon2){
		double lat1_rad = convertdecimaldegreestoradians(lat1);
		double lat2_rad = convertdecimaldegreestoradians(lat2);
		double lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1);
		double y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad);
		double x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad);
		return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
	}    

	public static double computespeed (long timediff, double distancediff){
		double tspeed;
		if(distancediff == 0){
			tspeed = 0;  
		}else{
			tspeed = distancediff / timediff;
		}

		return tspeed;
	} 

	public static double convertdecimaldegreestoradians(double deg){
		return (deg * Math.PI / 180);
	}

	/*decimal radian -> degree*/
	public static double convertradianstodecimaldegrees(double rad){
		return (rad * 180 / Math.PI);
	}		



}