package kafkaTutorial.tutorial;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import java.util.*;


public class Consumer {

	public static void main(String[] args) {
		Properties configs = new Properties();
		// 환경 변수 설정
		configs.put("bootstrap.servers", "localhost:9092");     // kafka server host 및 port
		configs.put("session.timeout.ms", "10000");             // session 설정
		configs.put("group.id", "kafka-nodejs-group");                // groupId 설정
		configs.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");    // key deserializer
		configs.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  // value deserializer
		configs.put("fetch.max.wait.ms", "5000");
		configs.put("fetch.min.bytes", "1");
		configs.put("fetch.max.bytes", "104857600");
		configs.put("enable.auto.commit", "false");
		configs.put("max.poll.records", "50000");
		configs.put("auto.offset.reset", "earliest");

		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(configs);    // consumer 생성

		consumer.subscribe(Collections.singletonList("fullNotification"));      // topic 설정 

		int count = 0, message_count = 0;
		try {
			long start = System.currentTimeMillis();
			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(1000);
				count++;
				for (ConsumerRecord<String, String> record : records) {
					//System.out.println("record.value(): " + record.value());
					message_count++;
					//System.out.println("message_count: "+ message_count); 	
				}
				long end = System.currentTimeMillis();


				if(message_count == 100000) { 
					System.out.println( "실행 시간 : " + ( end - start ) + "\ncount: " + count + "\nmessage_count: " + message_count); 
				}

				//System.out.println("count: "+ count);
				//System.out.println("msg_count: "+ message_count+ "\n"); //sysout 'ctrl+space'

			}
		}finally {       	
			consumer.close();
		}

	}

}