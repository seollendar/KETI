package keti.seolzero.JavaPreprocessing;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    		System.out.println("args: " + args[0]);
    
    	
//    	System.out.println(getDirection(37.412275, 127.129463, 37.411363, 127.130402));

    }
    
	/*bearing*/
	public static double getDirection(double lat1, double lon1, double lat2, double lon2){
		double lat1_rad = convertdecimaldegreestoradians(lat1);
		double lat2_rad = convertdecimaldegreestoradians(lat2);
		double lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1);
		double y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad);
		double x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad);
		return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
	}     

	public static double convertdecimaldegreestoradians(double deg){
		return (deg * Math.PI / 180);
	}

	/*decimal radian -> degree*/
	public static double convertradianstodecimaldegrees(double rad){
		return (rad * 180 / Math.PI);
	} 
}
