package keti.seolzero.JavaPreprocessing;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.log4j.Logger;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;
import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Consumer_v2_1 { //use org.json
	static InfluxDB influxDB = InfluxDBFactory.connect("http://localhost:8086");
	static String dbName = "javaWriteTest";

	public static void main(String[] args) throws ParseException {
		//String topicName = args[0];
		//String topicName = "notiForPreproc";
		String topicName = "partition-test";
		
		final Logger logger = Logger.getLogger(Consumer_v2_1.class);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

		HashMap<String, Object> map = new HashMap<String, Object>(50000);//초기 용량(capacity)지정

		/*KAFKA 환경 변수 설정*/
		Properties configs = new Properties();
		configs.put("bootstrap.servers", "localhost:9092");   // localhost:9092 kafka:9093
		configs.put("session.timeout.ms", "10000");             
		configs.put("group.id", "kafka-nodejs-group");               
		configs.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");   
		configs.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
		configs.put("fetch.max.wait.ms", "5000");
		configs.put("fetch.min.bytes", "1");
		configs.put("fetch.max.bytes", "104857600");
		configs.put("enable.auto.commit", "false");
		configs.put("max.poll.records", "50000");
		configs.put("auto.offset.reset", "earliest");
		
		

		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(configs);    
		consumer.subscribe(Collections.singletonList(topicName)); //Notification, AErandomNotification, AErandomNotification2, notiDataForUseInDocker
		int message_count = 0;
		try {
			System.out.println("=====================================");
			System.out.println("= Consumer_v2_1 Pre-processing Module =");
			System.out.println("=== Topic: " + topicName + " ===" );
			System.out.println("=====================================");

			logger.info("=========================");
			logger.info("= Pre-processing Module =");
			logger.info("=========================");

			long start = System.currentTimeMillis();
			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(1000);

				for (ConsumerRecord<String, String> record : records) {
					System.out.println("record.value(): " + record);
					message_count++;

					String recordOfKafka = record.value();
					JSONObject notiObj = new JSONObject(recordOfKafka);
					JSONObject conObject = notiObj.getJSONObject("m2m:sgn").getJSONObject("nev").getJSONObject("rep").getJSONObject("m2m:cin").getJSONObject("con");
					double currentLatitude = conObject.getDouble("latitude");
					double currentLongitude = conObject.getDouble("longitude");
					String currentTime = conObject.getString("time");
					Date currentTimeParse = format.parse(currentTime);

					/* split device AE, container */
					String sur = notiObj.getJSONObject("m2m:sgn").getString("sur");
					String[] surSplitArray = sur.split("/");
					String AE = surSplitArray[4];        
					String container = surSplitArray[5]; 

					if(container.equals("scnt-location")) {
						JSONObject PreviousConObject = (JSONObject) map.get("previousData_"+AE);
						//                  System.out.println(PreviousConObject);

						if(PreviousConObject == null) {                     
							map.put("previousData_"+AE, conObject);   

						}else {

							double previousLatitude = PreviousConObject.getDouble("latitude");
							double previousLongitude = PreviousConObject.getDouble("longitude");
							String previousTime = PreviousConObject.getString("time");
							Date previousTimeParse = format.parse(previousTime);

							double preprocessingSpeed = getSpeed(previousLatitude, previousLongitude, previousTimeParse, currentLatitude, currentLongitude, currentTimeParse);
							double preprocessingDistance = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);
							double preprocessingDirection = getDirection(previousLatitude, previousLongitude, currentLatitude, currentLongitude);

							//							logger.info("["+ message_count +"] AE: "+ AE 									
							//									+ "\n    -[previousData]   Latitude: " + previousLatitude + " Longitude: " + previousLongitude + " Time: " + previousTimeParse
							//									+ "\n    -[currentData]     Latitude: " + currentLatitude + " Longitude: " + currentLongitude + " Time" + currentTimeParse
							//									+ "\n    -[Preprocessing]  Speed(m/s) "+ preprocessingSpeed + ", Distance(m): "+ preprocessingDistance + ", Direction: "+ preprocessingDirection);


							//System.out.println("-Speed "+ preprocessingSpeed + "\n-Distance: "+ preprocessingDistance + "\n-Direction: "+ preprocessingDirection);
							saveToInfluxDB();

							/*set previousData to HashMap*/               
							map.put("previousData_"+AE, conObject);
						}
					}else {
						System.out.println("container?: "+ container);
						saveToInfluxDB();
					}


				}
				long end = System.currentTimeMillis();
				if(message_count == 50000) { 
					System.out.println( "Pre-processed data count: " + message_count);
					System.out.println( "Time taken(ms): " + ( end - start )); 
					logger.info("=========================");
					logger.info( "Pre-processed data count: " + message_count);
					logger.info( "Time taken(ms): " + ( end - start ));

					message_count++; 
				}


			}
		}finally {          
			consumer.close();

		}

	}


	/*Speed*/
	public static double getSpeed(double previousLatitude, double previousLongitude, Date previousTimeParse, double currentLatitude, double currentLongitude, Date currentTimeParse) {
		double distancePerM = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);//이동거리(m)
		long TimeDiff = (currentTimeParse.getTime() - previousTimeParse.getTime())/1000; // 단위:s
		//      System.out.println("previousLatitude: "+previousLatitude+"\npreviousLongitude: "+previousLongitude+"\npreviousTimeParse"+previousTimeParse+"\ncurrentLatitude: "+currentLatitude+"\ncurrentLongitude: "+currentLongitude+"\ncurrentTimeParse"+currentTimeParse);
		double computevelocity = computespeed(TimeDiff, distancePerM);//이동속도

		return computevelocity;
	}

	/*Distance*/
	public static double getDistance(double previousLatitude, double previousLongitude, double currentLatitude, double currentLongitude) {
		double p = 0.017453292519943295;    // Math.PI / 180
		double a = 0.5 - Math.cos((currentLatitude - previousLatitude) * p)/2 + Math.cos(previousLatitude * p) * Math.cos(currentLatitude * p) * (1 - Math.cos((currentLongitude - previousLongitude) * p))/2;
		return (12742 * Math.asin(Math.sqrt(a))*1000);
	}

	/*bearing*/
	public static double getDirection(double lat1, double lon1, double lat2, double lon2){
		double lat1_rad = convertdecimaldegreestoradians(lat1);
		double lat2_rad = convertdecimaldegreestoradians(lat2);
		double lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1);
		double y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad);
		double x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad);
		return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
	}    

	public static double computespeed (long timediff, double distancediff){
		double tspeed;
		if(timediff == 0){
			tspeed = 0;  
		}else{
			tspeed = distancediff / timediff;
		}
		return tspeed;
	} 

	public static double convertdecimaldegreestoradians(double deg){
		return (deg * Math.PI / 180);
	}

	public static double convertradianstodecimaldegrees(double rad){
		return (rad * 180 / Math.PI);
	}      

	
	public static void saveToInfluxDB() {
		//System.out.println("SAVE");
	}
	
	/* InfluxDB */
	public static void saveToInfluxDB(String dbName, String AE, double preprocessingSpeed, double preprocessingDistance, double preprocessingDirection) {

		Point points = Point.measurement(AE)
				.time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
				.addField("speed", preprocessingSpeed)
				.addField("distance", preprocessingDistance)
				.addField("direction", preprocessingDirection)
				.build();
		influxDB.write(dbName, "autogen", points);
	}

	/* MOBIUS */
	public static void postToMobius(String AE, double preprocessingSpeed, double preprocessingDistance, double preprocessingDirection) {
		OkHttpClient client = new OkHttpClient().newBuilder()
				.build();
		MediaType mediaType = MediaType.parse("application/json; ty=4");
		RequestBody body = RequestBody.create(mediaType, "{\n  \"m2m:cin\": {\n    \"cnf\": \"application/json\",\n    \"con\":{\n            \"ae\": \"" + AE + "\",\n            \"speed\": \"" +preprocessingSpeed+ "\",\n            \"distance\" : \""+preprocessingDistance+"\"           \n          }\n  }\n}");
		Request request = new Request.Builder()
				.url("localhost:7579/Mobius/ae_simple/cnt_simple")
				.method("POST", body)
				.addHeader("Accept", "application/json")
				.addHeader("X-M2M-RI", "123sdfgd45")
				.addHeader("X-M2M-Origin", "S20170717074825768bp2l")
				.addHeader("Content-Type", "application/json; ty=4")
				.addHeader("content-location", "ae-influx")
				.build();
		try {
			Response response = client.newCall(request).execute();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}