package keti.seolzero.JavaPreprocessing;


import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Properties;
import java.time.Duration;
 
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
 

public class SpecificPartitionConsumer {
    
    /**
     * 특정 파티션 할당
     */
    public static void specificPart() {
        Properties configs = new Properties();
        configs.put("bootstrap.servers", "localhost:9092");
        //특정 파티션을 할당하기 위해서는 기존과는 다른 그룹아이디 값을 주어야한다. 왜냐하면 컨슈머 그룹내에 같이 있게되면 서로의
        //오프셋을 공유하기 때문에 종료된 컨슈머의 파티션을 다른 컨슈머가 할당받아 메시지를 이어서 가져가게 되고, 오프셋을 커밋하게 된다.
        configs.put("group.id", "specificPart");
        configs.put("enable.auto.commit", "false");
        configs.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        configs.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        configs.put("auto.offset.reset", "earliest");
        
        String topicName = "partition-test";
        
        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(configs);
        consumer.subscribe(Collections.singletonList(topicName));
//        consumer.assign(Collections.singleton(new TopicPartition(topicName, 1)));
        
        try {

			System.out.println("=== Topic: " + topicName + " ===" );
			System.out.println("=====================================");
            
            while (true) {
              //컨슈머는 토픽에 계속 폴링하고 있어야한다. 아니면 브로커는 컨슈머가 죽었다고 판단하고, 해당 파티션을 다른 컨슈머에게 넘긴다.
              ConsumerRecords<String, String> records = consumer.poll(1000);
              for (ConsumerRecord<String, String> record : records) {
                //log.info("Topic: {}, Partition: {}, Offset: {}, Key: {}, Value: {}\n", record.topic(), record.partition(), record.offset(), record.key(), record.value());
            	  System.out.println("Topic: {}, Partition: {}, Offset: {}, Key: {}, Value: {}\n"+ record.topic()+ record.partition()+ record.offset()+record.key()+ record.value());
            	  System.out.println("record.value(): " + record);
              }
              //consumer.commitSync();
            }
        } finally {}
    }
    
    public static void main(String[] args) {

        specificPart();
    }
 
}

