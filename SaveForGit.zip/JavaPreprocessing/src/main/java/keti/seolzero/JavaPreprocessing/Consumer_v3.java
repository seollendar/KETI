package keti.seolzero.JavaPreprocessing;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.ParseException;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class Consumer_v3 { //UjSONIterator
	private static final Logger logger = Logger.getLogger(Consumer_v3.class);

	public static void main(String[] args) throws ParseException, IOException, InterruptedException {
		//      log4j.properties 파일 불러오고
		//		FileInputStream log4jRead = new FileInputStream ("C:\\eclipsework\\JavaPreprocessing\\SourceFolder\\log4j.properties");
		//		Properties log4jProperty=new Properties (); 
		//		log4jProperty.load (log4jRead); 
		//      property 타입으로 읽어서 configure와 연동
		//		PropertyConfigurator.configure(log4jProperty);

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		HashMap<String, String> map = new HashMap<String, String>(50000);//초기 용량(capacity)지정

		/*KAFKA 환경 변수 설정*/
		Properties configs = new Properties();
		configs.put("bootstrap.servers", "localhost:9092");    
		configs.put("session.timeout.ms", "10000");             
		configs.put("group.id", "kafka-nodejs-group");               
		configs.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");   
		configs.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
		configs.put("fetch.max.wait.ms", "5000");
		configs.put("fetch.min.bytes", "1");
		configs.put("fetch.max.bytes", "104857600");
		configs.put("enable.auto.commit", "false");
		configs.put("max.poll.records", "50000");
		configs.put("auto.offset.reset", "earliest");

		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(configs);    
		consumer.subscribe(Collections.singletonList("fullNotification")); //Notification, AErandomNotification, AErandomNotification2

		int count = 0, message_count = 0;
		try {
			System.out.println("=====================================");
			System.out.println("= Consumer_v3 Pre-processing Module =");
			System.out.println("=====================================");

			logger.info("=========================");
			logger.info("= Pre-processing Module =");
			logger.info("=========================");

			long start = System.currentTimeMillis();	
			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(1000);
				count++;
				for (ConsumerRecord<String, String> record : records) {
					//System.out.println("record.value(): " + record.value());
					//System.out.println("message_count: " + message_count);

					message_count++;

					Any jsonObject = JsonIterator.deserialize(record.value());
					Object conObject = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
					logger.info("record.value(): " + conObject);

					Double currentLatitude = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con").get("latitude").toDouble();
					Double currentLongitude = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con").get("longitude").toDouble();
					String currentTime = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con").get("time").toString();
					Date currentTimeParse = format.parse(currentTime);


					/* split device AE, container */
					String sur = jsonObject.get("m2m:sgn").get("sur").toString();
					String[] surSplitArray = sur.split("/");
					String AE = surSplitArray[4];        
					String container = surSplitArray[5]; 

					if(container.equals("scnt-location")) {
						String PreviousCon = map.get("previousData_"+AE);

						//	                  System.out.println(PreviousConObject);

						if(PreviousCon == null) {                     
							map.put("previousData_"+AE, conObject.toString());
							//							if(message_count%1000 == 0) {							
							//								logger.info("["+ message_count +"] AE: "+ AE 
							//										+ ", No previous data, Save current data:  Latitude- " + currentLatitude + " Longitude- " + currentLongitude + " Time-" + currentTimeParse);
							//							}	

						}else {
							//System.out.println(PreviousCon+ PreviousCon.getClass().getName());
							Any PreviousConObject = JsonIterator.deserialize(PreviousCon);
							double previousLatitude = PreviousConObject.get("latitude").toDouble();
							double previousLongitude = PreviousConObject.get("longitude").toDouble();
							String previousTime = PreviousConObject.get("time").toString();
							Date previousTimeParse = format.parse(previousTime);

							double preprocessingSpeed = getSpeed(previousLatitude, previousLongitude, previousTimeParse, currentLatitude, currentLongitude, currentTimeParse);
							double preprocessingDistance = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);
							double preprocessingDirection = getDirection(previousLatitude, previousLongitude, currentLatitude, currentLongitude);
							//System.out.println("AE: "+ AE +"\n-Speed "+ preprocessingSpeed + "\n-Distance: "+ preprocessingDistance + "\n-Direction: "+ preprocessingDirection);

							/*logger.info("["+ message_count +"] AE: "+ AE 
									//+ "\n    -[previousData]   Latitude: " + previousLatitude + " Longitude: " + previousLongitude + " Time: " + previousTimeParse
									//+ "\n    -[currentData]    Latitude: " + currentLatitude + " Longitude: " + currentLongitude + " Time" + currentTimeParse
									//+ "\n    -[Preprocessing]  Speed(m/s) "+ preprocessingSpeed + ", Distance(m): "+ preprocessingDistance + ", Direction: "+ preprocessingDirection);
									+ ", Preprocessing Speed(m/s): "+ preprocessingSpeed + ", Distance(m): "+ preprocessingDistance + ", Direction: "+ preprocessingDirection);
							 */

							//							if(message_count%1000 == 0) {
							//								logger.info("["+ message_count +"] AE: "+ AE 
							//										//+ "\n    -[previousData]   Latitude: " + previousLatitude + " Longitude: " + previousLongitude + " Time: " + previousTimeParse
							//										//+ "\n    -[currentData]     Latitude: " + currentLatitude + " Longitude: " + currentLongitude + " Time" + currentTimeParse
							//										//+ "\n    -[Preprocessing]  Speed(m/s) "+ preprocessingSpeed + ", Distance(m): "+ preprocessingDistance + ", Direction: "+ preprocessingDirection);
							//										+ ", Preprocessing: Speed(m/s)- "+ preprocessingSpeed + ", Distance(m)- "+ preprocessingDistance + ", Direction- "+ preprocessingDirection);

							//							}


							//saveToInfluxDB(AE, preprocessingSpeed, preprocessingDistance, preprocessingDirection);
							/*set previousData to HashMap*/               
							map.put("previousData_"+AE, conObject.toString());
						}
					}else {
						System.out.println("container?: "+ container);
						saveToInfluxDB();
					}
					
					if(message_count == 100000) { 
						long end = System.currentTimeMillis();
						System.out.println( "Pre-processed data count: " + message_count);
						System.out.println( "Time taken(ms): " + ( end - start )); 
						logger.info("=========================");
						logger.info( "Pre-processed data count: " + message_count);
						logger.info( "Time taken(ms): " + ( end - start ));

					}

				}
				long end = System.currentTimeMillis();
				if(message_count == 100000) { 
					System.out.println( "Pre-processed data count" + message_count);
					System.out.println( "Time taken(ms): " + ( end - start ));
					logger.info("=========================");
					logger.info( "Pre-processed data count: " + message_count);
					logger.info( "Time taken(ms): " + ( end - start ));

					message_count++; 
				}


			}
		}finally {          
			consumer.close();

		}

	}


	/*Speed(m/s)*/
	public static double getSpeed(double previousLatitude, double previousLongitude, Date previousTimeParse, double currentLatitude, double currentLongitude, Date currentTimeParse) {
		double distancePerM = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);//이동거리(m)
		long TimeDiff = (currentTimeParse.getTime() - previousTimeParse.getTime())/1000; // 단위:s
		//      System.out.println("previousLatitude: "+previousLatitude+"\npreviousLongitude: "+previousLongitude+"\npreviousTimeParse"+previousTimeParse+"\ncurrentLatitude: "+currentLatitude+"\ncurrentLongitude: "+currentLongitude+"\ncurrentTimeParse"+currentTimeParse);
		double computevelocity = computespeed(TimeDiff, distancePerM);//이동속도

		return computevelocity; // (km/h)unit *3.6
	}

	/*Distance*/
	public static double getDistance(double previousLatitude, double previousLongitude, double currentLatitude, double currentLongitude) {
		double p = 0.017453292519943295;    // Math.PI / 180
		double a = 0.5 - Math.cos((currentLatitude - previousLatitude) * p)/2 + Math.cos(previousLatitude * p) * Math.cos(currentLatitude * p) * (1 - Math.cos((currentLongitude - previousLongitude) * p))/2;
		return (12742 * Math.asin(Math.sqrt(a))*1000);
	}

	/*bearing*/
	public static double getDirection(double lat1, double lon1, double lat2, double lon2){
		double lat1_rad = convertdecimaldegreestoradians(lat1);
		double lat2_rad = convertdecimaldegreestoradians(lat2);
		double lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1);
		double y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad);
		double x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad);
		return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
	}    

	public static double computespeed (long timediff, double distancediff){
		double tspeed;
		if(timediff == 0){
			tspeed = 0;  
		}else{
			tspeed = distancediff / timediff;
		}
		return tspeed;
	} 

	public static double convertdecimaldegreestoradians(double deg){
		return (deg * Math.PI / 180);
	}

	/*decimal radian -> degree*/
	public static double convertradianstodecimaldegrees(double rad){
		return (rad * 180 / Math.PI);
	}      

	public static void saveToInfluxDB() {
		//System.out.println("SAVE");
	}

	public static void saveToInfluxDB(String AE, double preprocessingSpeed, double preprocessingDistance, double preprocessingDirection) {
		//System.out.println("SAVE");
	}

}