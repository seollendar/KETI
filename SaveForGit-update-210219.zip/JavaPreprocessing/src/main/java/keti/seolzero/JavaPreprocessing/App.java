package keti.seolzero.JavaPreprocessing;

import java.util.HashMap;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    		System.out.println("args: " + args[0]);
    
    		/*REDIS*/
    		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
    		JedisPool pool = new JedisPool(jedisPoolConfig, "127.0.0.1", 6379);
    		Jedis jedis = pool.getResource();
    		
    		String ae = "seolzero";
    		
//    		HashMap<String, Double> map = new HashMap<String, Double>();
//    		map.put("lat", 37.411360);
//    		map.put("lng", 127.129459);
//    		
//    		jedis.hmset(ae, map);
    		jedis.hset(ae, "lat", "1");  
    	    String key = jedis.hget(ae, "lat");  
    		
    		
    		System.out.println(jedis.hgetAll(ae));
    		

    }
    
	/*bearing*/
	public static double getDirection(double lat1, double lon1, double lat2, double lon2){
		double lat1_rad = convertdecimaldegreestoradians(lat1);
		double lat2_rad = convertdecimaldegreestoradians(lat2);
		double lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1);
		double y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad);
		double x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad);
		return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
	}     

	public static double convertdecimaldegreestoradians(double deg){
		return (deg * Math.PI / 180);
	}

	/*decimal radian -> degree*/
	public static double convertradianstodecimaldegrees(double rad){
		return (rad * 180 / Math.PI);
	} 
}
