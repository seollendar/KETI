package keti.seolzero.JavaPreprocessing;

import java.util.concurrent.TimeUnit;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;

public class Influx {

	static InfluxDB influxDB = InfluxDBFactory.connect("http://localhost:8086");
	static String dbName = "javaWriteTest";


	public static void main(String[] args) {

		saveToInflux();

		System.out.println("DONE");
	}

	
	
	public static void saveToInflux() {
		
			Point point2 = Point.measurement("disk")
					.time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
					.addField("used", Math.random() * 80L)
					.addField("free", Math.random() * 30L)
					.build();
			influxDB.write(dbName, "autogen", point2);
		
		
	}


}
